<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
		#aa{background-color: rgb(0,0,51);
		}

		.fa {
			  padding: 5px;
			  font-size: 30px;
			  width: 40px;
			  text-align: center;
			  text-decoration: none;
			  margin: 5px 2px;
			}

		.fa-facebook {
  				background: #3B5998;
  				color: white;
			}

		.fa-twitter {
  				background: #55ACEE;
  				color: white;
			}

		.fa-youtube {
  				background: #bb0000;
  				color: white;
			}

		.fa-rss {
  				background: #ff6600;
  				color: white;
			}

	</style>
</head>
<body>


<?php

 echo "<div class='card' id='aa'>";
    echo "<div class='card-header'>";
  
      echo "<div class='col text-center'>";
          echo "<p style='color: white;'>&copy; 2020 | Centre For Open And Distance Learning | Uva Wellassa University of Sri Lanka</p>";
          echo "<a href='https://www.facebook.com/officialuwu/' class='fa fa-facebook'></a>";
          echo "<a href='' class='fa fa-twitter'></a>";
          echo "<a href='https://www.youtube.com/channel/UCbl7DUWHu0HjUHvwznmyXLA' class='fa fa-youtube'></a>";
          echo "<a href='http://www.uwu.ac.lk/' class='fa fa-rss'></a>";
      echo "</div>";
      echo "</div>";
      echo "</div>";

      ?>
</body>
</html>