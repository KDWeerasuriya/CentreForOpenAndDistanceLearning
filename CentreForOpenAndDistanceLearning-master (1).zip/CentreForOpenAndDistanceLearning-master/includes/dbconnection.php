<?php

$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "codl_information_management_system";

$Connection = mysqli_connect($serverName, $userName, $password, $dbName);
mysqli_report(MYSQLI_REPORT_OFF);
